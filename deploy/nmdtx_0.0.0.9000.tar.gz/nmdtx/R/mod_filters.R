#' filters UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_filters_ui <- function(id) {
  ns <- NS(id)
  tagList(
    selectizeInput(
      inputId = "gene_select",
      label = h2("Pick a gene:"),
      choices = NULL,
      selected = NULL,
      multiple = FALSE,
      options = list(create = FALSE)
    ),
    selectizeInput(
      inputId = "contrast_select",
      label = h2("Pick contrasts:"),
      choices = NULL,
      multiple = TRUE,
      options = list(
        create = FALSE,
        plugins = list("remove_button")
      )
    )
  )
}

#' filters Server Functions
#'
#' @noRd
mod_filters_server <- function(id, conn, state) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    updateSelectizeInput(
      session,
      "gene_select",
      selected = INITIAL_GENE,
      choices = tbl(conn, "gtf") %>% pull("gene_name") %>% unique() %>% sort(),
      server = TRUE
    )

    updateSelectizeInput(
      session,
      "contrast_select",
      choices = tbl(conn, "metadata") %>% pull("group") %>% unique() %>% sort(),
      server = TRUE,
      selected = INITIAL_CONTRAST,
    )

    observeEvent(input$gene_select, {
      state$gene_sel <- input$gene_select
    })

    observeEvent(input$contrast_select, {
      state$gene_sel <- input$contrast_select
    })
  })
}
