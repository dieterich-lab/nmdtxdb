# library(GenomicRanges)
# library(GenomicFeatures)
#
# setwd("/Volumes/beegfs//prj/Niels_Gehring/nmd_transcriptome/phaseFinal/cds_task_christoph/")
# a <- import("../../phaseFinal/stringtie_merge/merged_each.fix.gtf", )
# b <- import("Ribo-seq_ORFs.gtf")
# a_exons <- a %>% subset(type == 'exon') %>% split(~transcript_id)
# b_exons <- b %>% subset(type == 'exon') %>% split(~transcript_id)
#
# a_tx <- mapToTranscripts(unlist(a_exons), a_exons)
# # assumes the same genome
# b_tx <- mapToTranscripts(unlist(b_exons), a_exons)
#
# # find overlaps pairs
# pairs <- findOverlaps(a_exons, b_exons)
# # compare blocks between pairs
# blocks_match <- suppressWarnings(a_exons[from(pairs)] == b_exons[to(pairs)])
# blocks_match %>% head()
# # flag contigous blocks
# any_contigous <- \(.x) any(rle(.x)$lengths[rle(.x)$values == TRUE] >= 2)
# contigous_blocks_match <- lapply(blocks_match, any_contigous)
# pairs <- pairs[unlist(contigous_blocks_match)]
# # only 203 hits out of 74804
