# #!/usr/bin/env Rscript
# suppressPackageStartupMessages({
#   library(rtracklayer)
#   library(GenomicFeatures)
#   library(plyranges)
# })
#
# ref_match <- read.table(
#   "/Volumes/beegfs/prj/Niels_Gehring/nmd_transcriptome/phaseFinal/compared/fix_comp_ref.tracking",
#   col.names = c("query_id", "locus_id", "ref", "class_code", "sample_info"))
# ref_match$transcript_id <- str_split(ref_match$sample_info, "\\|", simplify = TRUE)
# ref_match$transcript_id  <- ref_match$transcript_id[, 2]
# ref_match <- ref_match %>%
#   mutate(class_code = case_when(
#     class_code == '=' ~ 'same_intron_chain',
#     class_code == 'n' ~ 'IR',
#     class_code %in% c('c', 'j', 'k') ~ 'splicing_variants',
#     TRUE ~ 'other'
#   ))
#
# ref_match2 <- ref_match %>% dplyr::select(transcript_id, class_code) %>% tibble::deframe()
#
# ref <- import("/Volumes/beegfs/prj/Niels_Gehring/nmd_transcriptome/phaseFinal/stringtie_merge/merged_each.fix.gtf")
# ensembl_102 <- rtracklayer::import("/Volumes/beegfs/biodb/genomes/homo_sapiens/GRCh38_102/GRCh38.102.SIRV.gtf")
# ref_bed12 <- rtracklayer::import.bed("/Volumes/beegfs/prj/Niels_Gehring/nmd_transcriptome/phaseFinal/cds_task_christoph/ref.bed12")
#
# # cdna sequence
# fa <- Biostrings::readAAStringSet("/Volumes/beegfs/prj/Niels_Gehring/nmd_transcriptome/phaseFinal/fasta/transcriptome.clean.fa")
# names(fa) <- gsub(" .*$", "", names(fa))
# names(cds) <- cds$transcript_id
# txdb <- ref |> subset(type == 'exon') |> dplyr::select(transcript_id) |> split(~transcript_id)
# # we drop transcripts without CDS
# cds <- setNames(nm = ref_bed12$name, GRanges(seqnames(ref_bed12), ref_bed12$thick, strand = strand(ref_bed12)))
# common <- intersect(names(cds), names(txdb))
# txdb <- txdb[common]
# cds <- cds[common]
# cds <- pintersect(cds, txdb[names(cds)], drop.nohit.ranges=TRUE)
# cds <- unlist(cds)
# cds_t <- pmapToTranscripts(cds, txdb[names(cds)])
# cds_t <- split(ranges(cds_t), names(cds_t))
# exons_t <- pmapToTranscripts(unlist(txdb), txdb[rep(names(txdb), times=lengths(txdb))])
# # tst <- pintersect(exons_t, cds_t[names(exons_t)])
#
# tx <- asBED(txdb)
# neg_idx <- which(strand(tx) == "-")
# tx$c_blocks <- tx$blocks
# tx$c_blocks <- revElements(tx$c_blocks, neg_idx)
# tx$c_blocks <- endoapply(
#   tx$c_blocks,
#   \(.x) IRanges(end = cumsum(width(.x)), width = width(.x))
# )
# tx$g_thick <- cds[tx$name]
# tx$t_thick <- cds_t[tx$name]
# tx$ref_match <- ref_match2[tx$name]
#
# tx <- tx[tx$ref_match == "same_intron_chain"]
# tx$length <- width(tx$g_thick)
#
#
# all(lengths(tx$g_thick ) == lengths(tx$c_thick))
# tx$source <- 'ensembl'
#
#
#
#
#
# # resolves Warning in valid.GenomicRanges.seqinfo(x, suggest.trim = TRUE)
# tx <- tx[all(start(tx$t_thick) > 0), ]
# tx <- tx[all(end(tx$t_thick) > 0), ]
#
