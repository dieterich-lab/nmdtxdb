#
# library(GenomicRanges)
# library(GenomicFeatures)
#
# setwd("/VOlumes/beegfs//prj/Niels_Gehring/nmd_transcriptome/phaseFinal/cds_task_christoph/")
# a <- rtracklayer::import("merged_each.bed")
# b <- rtracklayer::import("Ribo-seq_ORFs.bed")
#
# # find overlaps pairs
# pairs <- findOverlaps(a, b)
# # compare blocks between pairs
# blocks_match <- suppressWarnings(a[from(pairs), ]$blocks == b[to(pairs), ]$blocks)
# blocks_match %>% head()
# # flag contigous blocks
# any_contigous <- \(.x) any(rle(.x)$lengths[rle(.x)$values == TRUE] >= 2)
# contigous_blocks_match <- lapply(blocks_match, any_contigous)
# pairs <- pairs[unlist(contigous_blocks_match)]
# # only two hits
