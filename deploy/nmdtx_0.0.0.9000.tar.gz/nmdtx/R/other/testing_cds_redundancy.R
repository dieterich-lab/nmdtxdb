db <- readRDS("database3.RDS")

x <- db$bed12
x_canonical <- x[x$source == 'canonical', ]
thick <- IRanges(x_canonical$thick)
thick <- resize(thick, width = width(thick) - 2)
x[x$source == 'canonical', ]$thick <- as.character(thick)

x2 <- split(IRanges(x$thick), x$name)
x2 <- x2[lengths(x2) != 1]
x2_comp <- pcompare(unlist(heads(x2, 1)), unlist(tails(x2, 1)))
table(x2_comp) %>% prop.table() %>% round(2) %>% as.data.frame()
?rangeComparisonCodeToLetter
