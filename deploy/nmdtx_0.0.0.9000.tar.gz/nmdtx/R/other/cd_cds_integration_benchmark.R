# library(stringr)
#
# base_path <- "/Volumes/beegfs/prj/Niels_Gehring/nmd_transcriptome/"
#
# parse_start_codons <- function(file, source){
#   x <- Biostrings::readAAStringSet(file)
#   input_string <- names(x)
#   values <- str_extract_all(input_string, "[A-Z0-9.]+|\\d+|\\+|ATG")
#   df <- as.data.frame(do.call(rbind, values))
#   colnames(df) <- c("ENST_ID", "length", "start", "end", "orientation", "ATG", "ATG_position", "tx_length")
#   df$ATG <- NULL
#   df$orientation <- NULL
#   df$source <- source
#   df$sequence <- as.character(unname(x))
#   df
# }
#
# df0 <-  mcols(tx)[, c('name', 'length', 'source')] %>%
#   as_tibble() %>%
#   mutate(length = as.character(length)) %>%
#   rename(ENST_ID = name)
#
# df0 <- df0 %>% mutate(length = as.character(length))
#
# df1 <- parse_start_codons(
#   file.path(base_path, "Christoph/ORFnightmare/entire_transcriptome/start_codons_riboseq_orfs_longorf2"),
#   "start_codons_riboseq_orfs_longorf2")
#
# df2 <- parse_start_codons(
#   file.path(base_path, "Christoph/ORFnightmare/entire_transcriptome/start_codons_human-openprot_longorf2"),
#   "start_codons_human-openprot_longorf2")
#
# df3 <- read.table(
#   file.path(base_path, "Christoph/ORFnightmare/complete/longorf_cdna_relevant_biotype_STOP_closest_EJC.bed")) %>%
#   dplyr::select(V1, V3, V5) %>%
#   setNames(., c('ENST_ID', 'start', 'end')) %>%
#   mutate(
#     length = as.character(start - end),
#     end = as.character(start + end),
#     start = as.character(start),
#     source = 'cd_longorf')
#
# df <- bind_rows(df0, df1, df2, df3) %>%
#   as_tibble() %>%
#   dplyr::select(ENST_ID, source, length) %>%
#   mutate(
#     length = as.numeric(length),
#     source = str_extract(source, 'ensembl|riboseq|openprot|cd_longorf'),
#     source = factor(source, levels= c('ensembl', 'riboseq', 'openprot', 'cd_longorf'))) %>%
#   arrange(source, -length) %>%
#   group_by(ENST_ID) %>%
#   slice_head(n=1)
#
# df$ref_match <- ref_match2[df$ENST_ID]
#
# # bind_rows together
# # arrange by source, length
# # group_by take top
