# library(networkD3)
# library(tidyr)
#
# nodes <- data.frame(name = c("Complete Data", "IR", "Other", "Same_Intron_Chain", "Splicing_Variants", "Ensembl", "Riboseq", "OpenProt", "CD_LongORF"))
#
# # Your data frame
# melted_df <- df %>%
#   pivot_longer(
#     cols = -c(ENST_ID, source, length),
#     names_to = "ref_match",
#     values_to = "value")
#
# elted_df <- df %>%
#   pivot_longer(cols = -c(ENST_ID, source), names_to = "ref_match", values_to = "value")
#
# # Convert the "source" factor variable to character
# melted_df$source <- as.character(melted_df$source)
#
# # Create a unique identifier for the nodes
# nodes <- data.frame(name = unique(c(melted_df$ENST_ID, melted_df$ref_match, melted_df$source)))
#
# # Create a mapping of node names to unique IDs
# node_mapping <- data.frame(name = nodes$name, id = 1:nrow(nodes))
#
# # Map the node IDs to the melted data frame
# melted_df <- left_join(melted_df, node_mapping, by = c("name" = "name"))
#
# # Rename the columns
# colnames(melted_df) <- c("ENST_ID", "ref_match", "value", "source")
#
# # Rearrange the columns
# melted_df <- melted_df[, c("source", "ENST_ID", "ref_match", "value")]
#
# sankey <- sankeyNetwork(
#   Links = data,
#   Nodes = nodes,
#   Source = "source",
#   Target = "target",
#   Value = "value")
#
# # Display the plot
# print(sankey)
