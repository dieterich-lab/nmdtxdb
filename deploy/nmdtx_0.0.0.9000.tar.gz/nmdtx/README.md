
<!-- README.md is generated from README.Rmd. Please edit that file -->

# nmdtx

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

nmdtx is the front-end for the NMD transcriptome project.

## Installation

You can install the development version of nmdtx like so:

``` r
devtools::install_github("https://github.com/dieterich-lab/nmd-app")
```

## Dev

-   TODO

## Deployment

-   TODO
