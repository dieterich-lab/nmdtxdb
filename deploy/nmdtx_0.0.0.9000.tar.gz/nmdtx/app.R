pkgload::load_all(export_all = FALSE,helpers = FALSE,attach_testthat = FALSE)
options("golem.app.prod" = TRUE)
future::plan(future::multisession)
nmdtx::run_app()
