conn <- dbConnect(
  RPostgres::Postgres(),
  host = "10.250.140.12",
  port = 5432,
  password = "WZupLe2wpejLBz7R2qrKWQRUdNvcWaGoBvcpracviYSPJMQ4duCXaGpMWHN8PjBU",
  user = "postgres"
)

dbExecute(
  conn,
  "CREATE USER nmd_transcriptome_reader WITH PASSWORD 'L%9f2zFr8O$88$JA*UaWmXqbq^AXV6';"
)

dbExecute(
  conn,
  "CREATE DATABASE nmd_transcriptome WITH OWNER nmd_transcriptome_reader;"
)


dbExecute(
  conn,
  "GRANT USAGE ON SCHEMA public TO nmd_transcriptome_reader;"
)


dbExecute(
  conn,
  "GRANT SELECT ON ALL TABLES IN SCHEMA public TO nmd_transcriptome_reader;"
)


dbExecute(
  conn,
  "ALTER DEFAULT PRIVILEGES IN SCHEMA public
   GRANT SELECT ON TABLES TO nmd_transcriptome_reader;"
)


dbDisconnect(conn)
